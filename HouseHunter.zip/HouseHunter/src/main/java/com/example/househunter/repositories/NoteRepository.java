package com.example.househunter.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import com.example.househunter.models.Note;

public interface NoteRepository extends CrudRepository<Note, Long>{
	List<Note> findAll();
	Optional<Note> findById(Long id);
}
