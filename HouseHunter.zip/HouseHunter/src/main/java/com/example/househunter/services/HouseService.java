package com.example.househunter.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.househunter.models.House;
import com.example.househunter.repositories.HouseRepository;

@Service
public class HouseService {

	@Autowired
	private HouseRepository houseRepo;
	
	public House findHouseById(Long id) {
		Optional<House> house = houseRepo.findById(id);
		if(house.isPresent()) {
			return house.get();
		} else {
			return null;
		}
	}
	
	public List<House> findAllHouses() {
		return houseRepo.findAll();
	}
	
	public House createHouse(House newHouse) {
		return houseRepo.save(newHouse);
	}
	
	public void updateHouse(House house) {
		houseRepo.save(house);
	}
	
	public void deleteHouse(Long id) {
		houseRepo.deleteById(id);
	}

}
