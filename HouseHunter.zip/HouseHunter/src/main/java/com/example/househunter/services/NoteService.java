package com.example.househunter.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.househunter.models.Note;
import com.example.househunter.repositories.NoteRepository;

@Service
public class NoteService {

	@Autowired
	private NoteRepository noteRepo;
	
	public Note findNoteById(Long id) {
		Optional<Note> note = noteRepo.findById(id);
		if(note.isPresent()) {
			return note.get();
		} else {
			return null;
		}
	}
	
	public List<Note> findAllNotes() {
		return noteRepo.findAll();
	}
	
	public Note createNote(Note newNote) {
		return noteRepo.save(newNote);
	}

}