package com.example.househunter.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.example.househunter.models.House;

public interface HouseRepository extends CrudRepository<House, Long>{
	List<House> findAll();
	Optional<House> findById(Long id);
}
