package com.example.househunter.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.example.househunter.models.House;
import com.example.househunter.models.LoginUser;
import com.example.househunter.models.Note;
import com.example.househunter.models.User;
import com.example.househunter.services.HouseService;
import com.example.househunter.services.NoteService;
import com.example.househunter.services.UserService;

@Controller
public class HomeController {

	@Autowired
	private UserService userService;
	@Autowired
	private HouseService houseService;
	@Autowired
	private NoteService noteService;

	@GetMapping("/")
	public String index(Model model) {
		model.addAttribute("newUser", new User());
		model.addAttribute("loginUser", new LoginUser());
		return "index.jsp";
	}

	@PutMapping("/register")
	public String register(Model model, @Valid @ModelAttribute("newUser") User newUser, BindingResult result, HttpSession session) {
		User loggedUser = userService.register(newUser, result);
		if (result.hasErrors()) {
			model.addAttribute("loginUser", new LoginUser());
			return "index.jsp";
		} else {
			session.setAttribute("user_id", loggedUser.getId());
			return "redirect:/home";
		}
	}

	@PutMapping("/login")
	public String login(@Valid @ModelAttribute("loginUser") LoginUser loginUser, BindingResult result,
			HttpSession session, Model model) {
		User loggedUser = userService.findByEmail(loginUser, result);
		if (result.hasErrors()) {
			model.addAttribute("newUser", new User());
			return "index.jsp";
		} else {
			session.setAttribute("user_id", loggedUser.getId());
			return "redirect:/home";
		}
	}

	@GetMapping("/home")
	public String home(HttpSession session, Model model) {
		List<House> houses = houseService.findAllHouses();
		Long id = (Long) session.getAttribute("user_id");
		model.addAttribute("user", userService.findUserById(id));
		model.addAttribute("houses", houses);
		return "home.jsp";
	}

	@GetMapping("/listings/new")
	public String newHouses(@ModelAttribute("newHouse") House newHouse, HttpSession session) {
		return "newHouse.jsp";
	}

	@PutMapping("/listings/create")
	public String newHouse(@Valid @ModelAttribute("newHouse") House newHouse, BindingResult result, HttpSession session) {
		if (result.hasErrors()) {
			return "newHouse.jsp";
		} else {
			newHouse.setUser(userService.findUserById((Long) session.getAttribute("user_id")));
			houseService.createHouse(newHouse);
			return "redirect:/home";
		}
	}

	@GetMapping("/listings/{id}")
	public String view(Model model, @PathVariable("id") Long id, HttpSession session) {
		Long user_id = (Long) session.getAttribute("user_id");
		model.addAttribute("user", userService.findUserById(user_id));
		model.addAttribute("house", houseService.findHouseById(id));
		model.addAttribute("notes", houseService.findHouseById(id).getNotes());
		model.addAttribute("newNote", new Note());
		return "viewHouse.jsp";
	}

	@GetMapping("/listings/{id}/edit")
	public String edit(@PathVariable("id") Long id, Model model, HttpSession session) {
		House house = houseService.findHouseById(id);
		model.addAttribute("newHouse", new House());
		model.addAttribute("house", house);

		return "editHouse.jsp";
	}

	@PutMapping("/listings/{id}/update")
	public String updateHouse(@Valid @ModelAttribute("newHouse") House newHouse, BindingResult result, HttpSession session,
			@PathVariable("id") Long id) {
		if (result.hasErrors()) {
			return "editHouse.jsp";
		} else {
			newHouse.setId(id);
			newHouse.setUser(userService.findUserById((Long) session.getAttribute("user_id")));
			houseService.updateHouse(newHouse);
			return "redirect:/home";
		}
	}

	@DeleteMapping("/listings/{id}/delete")
	public String delete(@PathVariable("id") Long id) {
		houseService.deleteHouse(id);
		return "redirect:/home";
	}

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("user_id");
		return "redirect:/";
	}
	
	@PutMapping("/notes/{id}/create") 
	public String newNote(@Valid @ModelAttribute("newNote") Note newNote, BindingResult result, HttpSession session, @PathVariable("id") Long id) {
		if (result.hasErrors()) {
			return "viewHouse.jsp";
		} else {
			newNote.setUser(userService.findUserById((Long) session.getAttribute("user_id")));
			newNote.setHouse(houseService.findHouseById(id));
			noteService.createNote(newNote);
			return "redirect:/listings/" + id;
		}
	}

}
