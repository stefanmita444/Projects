document.getElementById("date").setAttribute("max", new Date().toISOString().split("T")[0]);
