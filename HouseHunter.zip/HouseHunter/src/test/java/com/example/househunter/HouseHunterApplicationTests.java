package com.example.househunter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HouseHunterApplicationTests {

	@Test
	void contextLoads() {
	}

}
